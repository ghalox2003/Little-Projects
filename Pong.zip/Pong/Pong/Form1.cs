﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pong
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Mid.BackColor = Color.FromArgb(100, Color.White);
            ScoreA.ForeColor = Color.FromArgb(100, Color.White);           //ForeColor changing transparency doesn't work
            ScoreP.ForeColor = Color.FromArgb(100, Color.White);
            Player.BackColor = Color.FromArgb(100, Color.White);
            Ai.BackColor = Color.FromArgb(100, Color.White);
        }
        int PlayerY = 261;
        int AiY = 261;
        int Speed = 15;
        bool Start = false;
        int BallX = 572;
        int BallY = 311;
        int Choice = 0;
        Random r = new Random();

        private void GamePanel_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (Char)Keys.Up)
            {
                PlayerY = PlayerY - Speed;
                Player.Location = new System.Drawing.Point(3, PlayerY);
                if (Start == false) { Start = true; Game(); }
            }
            if (e.KeyValue == (Char)Keys.Down)
            {
                PlayerY = PlayerY + Speed;
                Player.Location = new System.Drawing.Point(3, PlayerY);
                if (Start == false) { Start = true; Game(); }
            }
        }
        public void Game()
        {
            Ball.Visible = true;
            while (Ball.Bounds.IntersectsWith(Player.Bounds) == false)
            {
                BallX = BallX - 1;
                Ball.Location = new Point(BallX, BallY);
            }

            while (Start == true)
            {
                if (Ball.Bounds.IntersectsWith(Player.Bounds) == true)
                {
                    Choice = r.Next(1, 2);
                    Bounce();
                }
                if (Ball.Bounds.IntersectsWith(Ai.Bounds) == true)
                {
                    Choice = r.Next(3, 4);
                    Bounce();
                }
                if (Ball.Bounds.IntersectsWith(GamePanel.Bounds) == true)
                {
                    if(BallY <= 1) { Choice = 5; Bounce(); }                        //Top
                    if(BallY >= 621) { Choice = 6; Bounce(); }                      //Bottom
                    if(BallX <= 1) { Loose(Player); }                               //Left
                    if(BallX >= 1140) { Loose(Ai); }                                //Right
                }
            }
        }
        string Sender = "";
        public void Bounce()
        {
            foreach (Control control in GamePanel.Controls)
            {
                if (Choice == 1)
                {
                    while (Ball.Bounds.IntersectsWith(control.Bounds) == false) { BallX = BallX + r.Next(1, 3); BallY = BallY + r.Next(1, 3); Ball.Location = new Point(BallX, BallY); }
                }
                if (Choice == 2)
                {
                    while(Ball.Bounds.IntersectsWith(control.Bounds) == false) { BallX = BallX + r.Next(1, 3); BallY = BallY - r.Next(1, 3); Ball.Location = new Point(BallX, BallY); }
                }
                if (Choice == 3)
                {
                    while (Ball.Bounds.IntersectsWith(control.Bounds) == false) { BallX = BallX - r.Next(1, 3); BallY = BallY + r.Next(1, 3); Ball.Location = new Point(BallX, BallY); }
                }
                if (Choice == 4)
                {
                    while (Ball.Bounds.IntersectsWith(control.Bounds) == false) { BallX = BallX - r.Next(1, 3); BallY = BallY - r.Next(1, 3); Ball.Location = new Point(BallX, BallY); }
                }
                if (Choice == 5)
                {
                    while (Ball.Bounds.IntersectsWith(control.Bounds) == false) { BallX = BallX - r.Next(1, 3); BallY = BallY - r.Next(1, 3); Ball.Location = new Point(BallX, BallY); }
                }
                if (Choice == 6)
                {

                }
            }
        }
        public void Loose(Control id)
        {

        }
    }
}
