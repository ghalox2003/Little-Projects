﻿namespace Pong
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GamePanel = new System.Windows.Forms.Panel();
            this.Ball = new System.Windows.Forms.Panel();
            this.ScoreA = new System.Windows.Forms.Label();
            this.ScoreP = new System.Windows.Forms.Label();
            this.Ai = new System.Windows.Forms.Panel();
            this.Player = new System.Windows.Forms.Panel();
            this.Mid = new System.Windows.Forms.Panel();
            this.GamePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // GamePanel
            // 
            this.GamePanel.Controls.Add(this.Ball);
            this.GamePanel.Controls.Add(this.ScoreA);
            this.GamePanel.Controls.Add(this.ScoreP);
            this.GamePanel.Controls.Add(this.Ai);
            this.GamePanel.Controls.Add(this.Player);
            this.GamePanel.Controls.Add(this.Mid);
            this.GamePanel.Location = new System.Drawing.Point(0, 0);
            this.GamePanel.Name = "GamePanel";
            this.GamePanel.Size = new System.Drawing.Size(1166, 642);
            this.GamePanel.TabIndex = 0;
            this.GamePanel.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GamePanel_KeyDown);
            // 
            // Ball
            // 
            this.Ball.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Ball.Location = new System.Drawing.Point(572, 311);
            this.Ball.Name = "Ball";
            this.Ball.Size = new System.Drawing.Size(22, 21);
            this.Ball.TabIndex = 5;
            this.Ball.Visible = false;
            // 
            // ScoreA
            // 
            this.ScoreA.Font = new System.Drawing.Font("Impact", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScoreA.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ScoreA.Location = new System.Drawing.Point(668, 9);
            this.ScoreA.Name = "ScoreA";
            this.ScoreA.Size = new System.Drawing.Size(216, 273);
            this.ScoreA.TabIndex = 4;
            this.ScoreA.Text = "0";
            this.ScoreA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ScoreP
            // 
            this.ScoreP.Font = new System.Drawing.Font("Impact", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScoreP.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ScoreP.Location = new System.Drawing.Point(286, 9);
            this.ScoreP.Name = "ScoreP";
            this.ScoreP.Size = new System.Drawing.Size(216, 273);
            this.ScoreP.TabIndex = 3;
            this.ScoreP.Text = "0";
            this.ScoreP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Ai
            // 
            this.Ai.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Ai.Location = new System.Drawing.Point(1141, 261);
            this.Ai.Name = "Ai";
            this.Ai.Size = new System.Drawing.Size(22, 121);
            this.Ai.TabIndex = 2;
            // 
            // Player
            // 
            this.Player.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Player.Location = new System.Drawing.Point(3, 261);
            this.Player.Name = "Player";
            this.Player.Size = new System.Drawing.Size(22, 121);
            this.Player.TabIndex = 1;
            // 
            // Mid
            // 
            this.Mid.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Mid.Location = new System.Drawing.Point(572, 1);
            this.Mid.Name = "Mid";
            this.Mid.Size = new System.Drawing.Size(22, 641);
            this.Mid.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1165, 641);
            this.Controls.Add(this.GamePanel);
            this.Name = "Form1";
            this.Text = "Pong!";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GamePanel_KeyDown);
            this.GamePanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel GamePanel;
        private System.Windows.Forms.Label ScoreA;
        private System.Windows.Forms.Label ScoreP;
        private System.Windows.Forms.Panel Ai;
        private System.Windows.Forms.Panel Player;
        private System.Windows.Forms.Panel Mid;
        private System.Windows.Forms.Panel Ball;
    }
}

